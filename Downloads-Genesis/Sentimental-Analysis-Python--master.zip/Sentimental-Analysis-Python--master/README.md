![Python package](https://github.com/99002500/Sentimental-Analysis-Python-/workflows/Python%20package/badge.svg)
[![Codacy Badge](https://app.codacy.com/project/badge/Grade/9808e9aede5048c3b7a683bf7953346f)](https://www.codacy.com/gh/99002500/Sentimental-Analysis-Python-/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=99002500/Sentimental-Analysis-Python-&amp;utm_campaign=Badge_Grade)
![Pylint](https://github.com/99002500/Sentimental-Analysis-Python-/workflows/Pylint/badge.svg)
