# Calculator-Project
![cppcheck-action](https://github.com/99002500/Calculator-Project/workflows/cppcheck-action/badge.svg)
