#ifndef __HEADER_H__
#define __HEADER_H__
void pinchecker();
#endif