# Super Mario Implementation in Python

## Creator 

Nirankar Nath Singh 

Please Subscribe My Youtube channel 

Name : Brain Flicks

Link : https://www.youtube.com/nirankarnathsingh

Instagram : https://www.instagram.com/bnirankar
## Running

* $ pip install -r requirements.txt
* $ python main.py

## Standalone windows build

* $ pip install py2exe
* $ python compile.py py2exe

## Controls

* Left: Move left  // Left Arrow
* Right: Move right  //Right Arror
* Space: Jump       //Up Arror
* Shift: Boost   
* Left/Right Mouseclick: Secret   

## Current state:
![Alt text](img/pics.png "current state")

## Dependencies	
* pygame	
* scipy	

## Contribution

If you have any Improvements/Ideas/Refactors feel free to contact me or make a Pull Request.
The code needs still alot of refactoring as it is right now, so I appreciate any kind of Contribution.
