
![cppcheck-action](https://github.com/99002487/genesis_sdlc/workflows/cppcheck-action/badge.svg)
![C/C++ CI](https://github.com/99002487/genesis_sdlc/workflows/C/C++%20CI/badge.svg)
