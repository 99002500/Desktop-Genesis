declare interface Thenable<T> extends PromiseLike<T> {}

declare module "globule";
